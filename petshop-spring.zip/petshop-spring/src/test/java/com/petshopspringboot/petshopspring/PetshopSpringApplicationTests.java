package com.petshopspringboot.petshopspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetshopSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
