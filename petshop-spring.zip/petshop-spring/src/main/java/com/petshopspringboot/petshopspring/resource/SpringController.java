package com.petshopspringboot.petshopspring.resource;

import com.petshopspringboot.petshopspring.model.Animal;
import com.petshopspringboot.petshopspring.repository.AnimalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class SpringController {
    @Autowired
    AnimalRepository animalsRepository;

    @GetMapping(value = "/animals")
    public List<Animal> getByTypes(@RequestParam(value = "type", required = false) String type){
        if(type != null) {
            ArrayList<Animal> temp = new ArrayList<Animal>();
            for (Animal t : animalsRepository.findAll()) {
                if (t.getType().equalsIgnoreCase(type))
                    temp.add(t);
            }
            return temp;
        }else return animalsRepository.findAll();
    }
    public List<Animal> getAll(){
        return animalsRepository.findAll();
    }

    @GetMapping(value = "/animals/{id}")
    public Animal getOne(@PathVariable int id){
        for (Animal t : animalsRepository.findAll()) {
            if (t.getId() == id)
                return t;
        }
        return null;
    }

    @PostMapping(value = "/add")
    public List<Animal> Add(@RequestBody final Animal animal){
        animalsRepository.save(animal);
        return animalsRepository.findAll();
    }

    @DeleteMapping(value = "/animals")
    public List<Animal> deleteAnimal(@RequestParam(value = "id") int id ){
        try {
            animalsRepository.deleteById(id);
            return animalsRepository.findAll();
        }catch(Exception e){
            return null;
        }


    }

    @PutMapping(value = "/animals")
    public Animal updateAnimal(@RequestBody Animal animal){
        for (Animal t : animalsRepository.findAll()) {
            if (t.getId() == animal.getId()) {
                t.setAge(animal.getAge());
                t.setName(animal.getName());
                t.setPrice(animal.getPrice());
                t.setSex(animal.getSex());
                t.setType(animal.getType());
                return animalsRepository.save(t);

            }

        }


        return null;

    }


}
